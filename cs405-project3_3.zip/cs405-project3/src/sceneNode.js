/**
 * @class SceneNode
 * @desc A SceneNode is a node in the scene graph.
 * @property {MeshDrawer} meshDrawer - The MeshDrawer object to draw
 * @property {TRS} trs - The TRS object to transform the MeshDrawer
 * @property {SceneNode} parent - The parent node
 * @property {Array} children - The children nodes
 */

class SceneNode {
    constructor(meshDrawer, trs, parent = null) {
        this.meshDrawer = meshDrawer;
        this.trs = trs;
        this.parent = parent;
        this.children = [];

        if (parent) {
            this.parent.__addChild(this);
        }
    }

    __addChild(node) {
        this.children.push(node);
    }

    draw(mvp, modelView, normalMatrix, modelMatrix) {
        // Original variable declarations
        var transformedMvp = mvp;
        var transformedModelView = modelView;
        var transformedNormals = normalMatrix;
        var transformedModel = modelMatrix;
    
        // Apply the parent's transformations
        const parentTransformedMvp = this.parent ? this.parent.trs.applyTRS(mvp) : mvp;
        const parentTransformedModelView = this.parent ? this.parent.trs.applyTRS(modelView) : modelView;
        const parentTransformedNormals = this.parent ? this.parent.trs.applyTRS(normalMatrix) : normalMatrix;
        const parentTransformedModel = this.parent ? this.parent.trs.applyTRS(modelMatrix) : modelMatrix;
    
        // Combine parent and current node transformations
        transformedMvp = this.trs.applyTRS(parentTransformedMvp);
        transformedModelView = this.trs.applyTRS(parentTransformedModelView);
        transformedNormals = this.trs.applyTRS(parentTransformedNormals);
        transformedModel = this.trs.applyTRS(parentTransformedModel);
    
        // Draw the MeshDrawer
        if (this.meshDrawer) {
            this.meshDrawer.draw(transformedMvp, transformedModelView, transformedNormals, transformedModel);
        }
    
        // Draw children nodes recursively
        for (const child of this.children) {
            child.draw(transformedMvp, transformedModelView, transformedNormals, transformedModel);
        }
    }

}