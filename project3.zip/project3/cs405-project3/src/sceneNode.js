/**
 * @class SceneNode
 * @desc A SceneNode is a node in the scene graph.
 * @property {MeshDrawer} meshDrawer - The MeshDrawer object to draw
 * @property {TRS} trs - The TRS object to transform the MeshDrawer
 * @property {SceneNode} parent - The parent node
 * @property {Array} children - The children nodes
 */

class SceneNode {
    constructor(meshDrawer, trs, parent = null) {
        this.meshDrawer = meshDrawer;
        this.trs = trs;
        this.parent = parent;
        this.children = [];

        if (parent) {
            this.parent.__addChild(this);
        }
    }

    __addChild(node) {
        this.children.push(node);
    }


    draw(mvp, modelView, normalMatrix, modelMatrix, visited = new Set()) {
        // Prevent infinite recursion by marking visited nodes
        if (visited.has(this)) {
            console.error("Infinite loop detected at node:", this);
            return; // Stop further recursion
        }
        visited.add(this);
    
        // 1. Compute the transformation matrix for this node
        const translationMatrix = this.trs.getTranslationMatrix();
        const rotationMatrix = this.trs.getRotationMatrix();
        const scalingMatrix = this.trs.getScaleMatrix();
        const nodeTransform = MatrixMult(rotationMatrix, MatrixMult(translationMatrix, scalingMatrix));
        const combinedModelMatrix = MatrixMult(modelMatrix, nodeTransform);
    
        // 2. Update transformation matrices
        const updatedModelView = MatrixMult(modelView, combinedModelMatrix);
        const updatedNormalMatrix = getNormalMatrix(combinedModelMatrix);
        const updatedMvp = MatrixMult(mvp, combinedModelMatrix);
    
        // 3. Draw this node's mesh
        if (this.meshDrawer) {
            this.meshDrawer.draw(updatedMvp, updatedModelView, updatedNormalMatrix, combinedModelMatrix);
        }
    
        // 4. Recursively draw all child nodes
        for (let i = 0; i < this.children.length; i++) {
            const child = this.children[i];
            child.draw(updatedMvp, updatedModelView, updatedNormalMatrix, combinedModelMatrix, visited);
        }
    }
    
    

}